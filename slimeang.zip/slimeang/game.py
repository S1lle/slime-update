from pygame import *
from random import randint
init()
w = 1600
h = 800
info = display.Info()
fullscreen_size = (info.current_w, info.current_h)
is_fullscreen = False
window = display.set_mode((w, h), RESIZABLE)
clock = time.Clock()
start = 10000
Fps = 80
loose_bg = transform.scale(image.load("loose_bg.jpg"), (w, h))
mixer.init()
mixer.music.load("music.ogg")
mixer.music.set_volume(0.35)
mixer.music.play()
death = mixer.Sound("death.ogg")
regenerate = mixer.Sound("life.ogg")
loose = mixer.Sound("loose.ogg")
knockknock = mixer.Sound("knock-knock.ogg")
huh = mixer.Sound("time.ogg")
virtual_surface = Surface((w, h))
current_size = window.get_size()
last_size = current_size
up = False
down = False
left = False
right = False
leftb = False
rightb = False

catan = [image.load("cat1.png")]
catan2 = [image.load("cat2.png")]
walkright = [image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png"),image.load("right.png")]
walkleft = [image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png"),image.load("left.png")]
walkup = [image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png"),image.load("up.png")]
walkdown = [image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png"),image.load("down.png")]
idle = [image.load("stand.png")]
global lost
lost = 0
class Main_ch(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Main_charcter(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(150, 150))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Main_charcter1(sprite.Sprite):
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(450, 450))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000
class Heart():
    def __init__(self, x, y, speed, i):
        super().__init__()
        self.image = transform.scale(image.load(i),(100, 100))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.left = False
        self.right = False
        self.up = False
        self.down= False
        self.idle = False
        self.count = 0
    def reset(self):
        virtual_surface.blit(self.image,(self.rect.x,self.rect.y))
    def hide(self):
        self.rect.x += 100000
    def show(self):
        self.rect.x -= 100000

class Slime(Main_charcter):
    def update(self):
        keys = key.get_pressed()
        if keys[K_a] or keys[K_LEFT] and self.rect.x > 10:
            global speed
            self.rect.x -= self.speed
            self.left = True
            self.right = False
            self.down = False
            self.up = False
            up = False
            down = False
            left = True
            right = False
            self.idle = False
            start = 10000
        elif keys[K_d] or keys[K_RIGHT] and self.rect.x < 800:
            global speed
            self.rect.x += self.speed
            self.left = False
            self.right = True
            self.down = False
            self.up = False
            up = False
            down = False
            left = False
            right = True
            self.idle = False
            start = 10000
        elif keys[K_w] or keys[K_UP] and self.rect.y < 1000:
            self.rect.y -= self.speed
            self.left = False
            self.right = False
            self.down = False
            self.up = True
            up = True
            down = False
            left = False
            right = False
            self.idle = False
            start = 10000
        elif keys[K_s] or keys[K_DOWN] and self.rect.y > 10 or self.rect.y > 500:
            self.rect.y += self.speed
            self.left = False
            self.right = False
            self.down = True
            self.up = False
            up = False
            down = True
            left = False
            right = False
            self.idle = False
            start = 10000
            if self.rect.y > 900:
                    global lost
                    lost += 1
                    self.rect.x = 100
                    self.rect.y = 100
                    death.play()
        elif idle:
            self.idle = True
            self.left = False
            self.right = False
            self.down = False
            self.up = False
            self.count = 0
            self.up = False
            up = False
            down = False
            left = False
            right = False
            self.idle = False
    def animation(self):
        if self.count + 1 >= 30:
            self.count = 0
        if self.left == True:
            virtual_surface.blit(walkleft[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.right == True:
            virtual_surface.blit(walkright[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.up == True:
            virtual_surface.blit(walkup[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        elif self.down == True:
            virtual_surface.blit(walkdown[self.count//10],(self.rect.x, self.rect.y))
            self.count += 1
        else:
            virtual_surface.blit(idle[self.count//10],(self.rect.x, self.rect.y))          
    def start1(self):
        self.rect.y = 100
        self.rect.x = 300
class Rabbit(Main_ch): 
    def update(self):
        rand = randint(1,25)
        rand4 = randint(1,25)
        rand1 = randint(1,2)
        if rand1 == 1:
            self.rect.x += rand
            self.right = True
            self.left = False
            self.rect.y -= rand4
            if self.rect.y > 550:
               self.rect.y -= 20
            elif self.rect.y > 600:
                self.rect.y += 500
            elif self.rect.x > 1600:
                self.rect.x -= 20
            elif self.rect.x > 1800:
                self.rect.x -= 500
            elif self.rect.y > 1600:
               self.rect.y += 20
            elif self.rect.y > 850:
               self.rect.y += 500
            elif self.rect.x > 10:
                self.rect.x += 20
            elif self.rect.x > 60:
                self.rect.x += 50
        if rand1 == 2:
            self.rect.x -= rand+40
            self.rect.y += rand4
            self.right = False
            self.left = True
            if self.rect.y > 550:
               self.rect.y -= 20
            elif self.rect.y > 600:
                self.rect.y += 500
            elif self.rect.x > 1600:
                self.rect.x -= 20
            elif self.rect.x > 1800:
                self.rect.x -= 500
            elif self.rect.y > 1600:
               self.rect.y += 20
            elif self.rect.y > 850:
               self.rect.y += 500
            elif self.rect.x > 10:
                self.rect.x += 20
            elif self.rect.x > 60:
                self.rect.x += 50
            



            
            
        
        

destroyed = False
tree1 = Main_charcter1(60, 100, 0, "tree.png")
mainch = Slime(100, 100, 8, "stand.png")
rabbit = Rabbit(500, 300, 1, "rabbit.png")
rabbit2 = Rabbit(700, 200, 1, "rabbit.png")
rabbit3 = Rabbit(100, 500, 1, "rabbit.png")
rabbit4 = Rabbit(300, 200, 1, "rabbit.png")
bg2 = transform.scale(image.load("floor.jpg"), (w, h))
heart1 = Heart(40, 10, 0, "heart.png")
heart2 = Heart(90, 10, 0, "heart.png")
heart3 = Heart(140, 10, 0, "heart.png")
bg3 = transform.scale(image.load("floor2.jpg"), (w, h))
game = True
final = False
bgx = 0
lose = False
click = 0
tut = False
while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
        if e.type == VIDEORESIZE:
            current_size = e.size
        if e.type == KEYDOWN:
            if e.key == K_F11:
                is_fullscreen = not is_fullscreen
                if is_fullscreen:
                    last_size = current_size
                    current_size = fullscreen_size
                    screen = display.set_mode(current_size, FULLSCREEN)
                else:
                    current_size = last_size
                    screen = display.set_mode(current_size, RESIZABLE)
                    screen = display.set_mode(current_size, RESIZABLE)
        
        

    if final != True:
        start -= 1
        if start <= 0:
            huh.play()
            knockknock.play()
        start = 10000

        virtual_surface.blit(bg3, (0, 0))
        if mainch.rect.x > 1605:
            virtual_surface.blit(bg3,(0, 0))
            mainch.rect.x = 50
            tree1.hide()
            mainch.reset()
            rabbit.hide()
            rabbit2.hide()
            rabbit3.hide()
            rabbit4.hide()
            mainch.update()
            mainch.animation()
        elif mainch.rect.x < 10:
            virtual_surface.blit(bg2, (0, 0))
            mainch.rect.x = 1590
            tree1.show()
            tree1.update()
            mainch.reset()
            rabbit.show()
            rabbit2.show()
            rabbit3.show()
            rabbit4.show()
            mainch.update()
            mainch.animation()
        
        tree1.update()
        rabbit.reset()
        rabbit2.reset()
        rabbit3.reset()
        rabbit4.reset()
        mainch.reset()
        mainch.update()
        mainch.animation()
        tree1.reset()
        heart1.reset()
        heart2.reset()
        heart3.reset()
        rand3 = randint(1, 50)
        if rand3 == 50:
            rabbit.update()
        if rand3 == 28:
            rabbit2.update()
        if rand3 == 22:
            rabbit3.update()
        if rand3 == 10:
            rabbit4.update()
        if lost == 1:
            heart3.hide()
        if lost == 2:
            heart2.hide()
        if lost == 3:
            heart1.hide()
            final = True
            lose = True
            mixer.music.stop()
    if final == True:
        loose.play(True)
        loose.set_volume(0.1)
        virtual_surface.blit(loose_bg, (bgx +0, 0))
        virtual_surface.blit(loose_bg, (bgx +1050, 0))
        bgx -= 2
        if bgx == -1050:
            bgx = 0
        
    
    scaled_surface = transform.scale(virtual_surface, current_size)
    window.blit(scaled_surface,(0, 0))
    display.update()
    clock.tick(Fps)